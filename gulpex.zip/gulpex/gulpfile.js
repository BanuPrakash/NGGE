const gulp = require('gulp');
const eslint = require('gulp-eslint')
const babel = require('gulp-babel');
const plumber = require('gulp-plumber');


const concat = require('gulp-concat');
const del = require('del');
const uglify = require('gulp-uglify');

gulp.task('clean', () => {
  return del(['build/**']);
});

gulp.task('default', () => {
  return gulp.src('./src/**/*.js')
    // Stop the process if an error is thrown.
    .pipe(plumber())  
    .pipe(concat('main.js'))
    .pipe(babel({
      presets: [
        ['@babel/env', {
          modules: false
        }]
      ]
    }))
    .pipe(uglify())
    .pipe(gulp.dest('./build'))
});

gulp.task('lint', function() {
  return gulp    
    // Define the source files
    .src('src/**/*.js').pipe(eslint({
      rules: {
        "no-console": "off",
        'linebreak-style': ['error', 'windows'],  // changes the file to CRLF
        }
    }))
    // Output the results in the console
    .pipe(eslint.format());
});
