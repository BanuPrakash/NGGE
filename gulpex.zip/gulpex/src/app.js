const add = (x, y) => x + y;

console.log(add(3, 4));
